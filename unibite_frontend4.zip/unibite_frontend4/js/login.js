function isValidEmail(email) {
    return /^\S+@\S+\.\S+$/.test(String(email || "").trim());
}

function initLogin() {
    const form = document.getElementById("login-form");
    if (!form) return;

    const tabLogin = document.getElementById("tab-login");
    const tabSignup = document.getElementById("tab-signup");
    const signupExtra = document.getElementById("signup-extra");
    const submitBtn = document.getElementById("submit-auth");
    const passwordInput = document.getElementById("password");
    const confirmPasswordInput = document.getElementById("confirm-password");
    const togglePasswordBtn = document.getElementById("toggle-password");

    let mode = "login";

    function setMode(nextMode) {
        mode = nextMode;
        signupExtra.classList.toggle("hidden", mode === "login");
        submitBtn.textContent = mode === "login" ? "Login" : "Sign up";
        tabLogin.classList.toggle("active", mode === "login");
        tabSignup.classList.toggle("active", mode === "signup");
    }

    tabLogin?.addEventListener("click", () => setMode("login"));
    tabSignup?.addEventListener("click", () => setMode("signup"));

    togglePasswordBtn?.addEventListener("click", () => {
        const show = passwordInput.type === "password";
        passwordInput.type = show ? "text" : "password";
        if (confirmPasswordInput) confirmPasswordInput.type = passwordInput.type;
        togglePasswordBtn.textContent = show ? "Hide" : "Show";
    });

    setMode("login");

    form.addEventListener("submit", async event => {
        event.preventDefault();

        let username = (document.getElementById("username").value || "").trim();
        const password = document.getElementById("password").value || "";

        if (!username || !password) {
            showToast("Please fill all required fields.", "warning");
            return;
        }

        const isAdminAttempt = username.toLowerCase() === "admin";
        if (!username.startsWith("@") && !isAdminAttempt) username = "@" + username;

        const users = getUsers();
        const existing = users.find(user => normalizeUser(user.username) === normalizeUser(username));

        if (mode === "login") {
            if (isAdminAttempt && password === "admin") {
                localStorage.setItem("CURRENT_USER", "admin");
                localStorage.setItem("CURRENT_USER_ID", "4");
                localStorage.setItem("IS_ADMIN", "true");
                window.CURRENT_USER = "admin";
                showToast("Admin login successful.", "success");
                window.location.href = "admin.html";
                return;
            }

            if (!existing) {
                showToast("User not found. Please use Sign up.", "warning");
                setMode("signup");
                return;
            }

            if (existing.password !== btoa(String(password))) {
                showToast("Invalid credentials.", "error");
                return;
            }

            localStorage.setItem("CURRENT_USER", existing.username);
            localStorage.setItem("IS_ADMIN", existing.role === "admin" ? "true" : "false");
            if (existing.backendId) localStorage.setItem("CURRENT_USER_ID", String(existing.backendId));
            else localStorage.setItem("CURRENT_USER_ID", String(getDemoUserId(existing.username)));
            window.CURRENT_USER = existing.username;
            ensureCurrentUserProfile();
            showToast("Login successful.", "success");
            window.location.href = "index.html";
            return;
        }

        const email = (document.getElementById("email").value || "").trim();
        const confirm = document.getElementById("confirm-password").value || "";

        if (!isValidEmail(email)) {
            showToast("Please enter a valid email.", "warning");
            return;
        }

        if (password.length < 4) {
            showToast("Password must be at least 4 characters.", "warning");
            return;
        }

        if (password !== confirm) {
            showToast("Passwords do not match.", "warning");
            return;
        }

        if (existing) {
            showToast("User already exists. Please login.", "warning");
            setMode("login");
            return;
        }

        const newUser = {
            username,
            password: btoa(String(password)),
            email,
            points: 5,
            createdAt: Date.now(),
            role: "student"
        };

        try {
            if (window.UniBiteAPI) {
                const result = await window.UniBiteAPI.UsersAPI.register({
                    name_lastname: username.replace("@", ""),
                    email
                });
                newUser.backendId = result.user_id;
                window.UniBiteAPI.setCurrentUserId(result.user_id);
            }
        } catch (error) {
            newUser.backendId = getDemoUserId(username);
            localStorage.setItem("CURRENT_USER_ID", String(newUser.backendId));
        }

        users.push(newUser);
        saveUsers(users);
        localStorage.setItem("CURRENT_USER", newUser.username);
        localStorage.setItem("IS_ADMIN", "false");
        window.CURRENT_USER = newUser.username;
        ensureCurrentUserProfile();
        showToast("Account created and logged in.", "success");
        window.location.href = "index.html";
    });
}

function getDemoUserId(username) {
    const key = normalizeUser(username);
    if (key === "cooknwave") return 1;
    if (key === "chefanna") return 2;
    if (key === "foodie") return 3;
    if (key === "admin") return 4;
    return 1;
}

window.initLogin = initLogin;
