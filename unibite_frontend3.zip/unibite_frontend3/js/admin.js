async function initAdmin() {
    const isAdmin = localStorage.getItem("IS_ADMIN") === "true";
    const currentUser = localStorage.getItem("CURRENT_USER");

    if (!isAdmin && normalizeUser(currentUser) !== "admin") {
        showToast("Access denied. Admin only.", "error");
        window.location.href = "index.html";
        return;
    }

    await loadStatistics();
    await loadLeaderboard();
    await loadTopMeals();
    loadRecentActivity();
}

async function loadStatistics() {
    try {
        const monthly = await window.UniBiteAPI.AdminAPI.monthlyPortions();
        document.getElementById("total-portions").textContent = monthly.total_portions_shared_last_month ?? 0;
    } catch (error) {
        document.getElementById("total-portions").textContent = getDeliveredRequests().length;
    }

    const users = getUsers();
    const meals = mealService.getAll();
    const ratings = JSON.parse(localStorage.getItem("ratings") || "[]");
    const requests = JSON.parse(localStorage.getItem("requests") || "[]");

    document.getElementById("total-users").textContent = users.length;
    document.getElementById("avg-rating").textContent = calculateAverageRating(ratings);
    document.getElementById("total-meals").textContent = meals.length;
    document.getElementById("pending-requests").textContent = requests.filter(item => item.status === "pending").length;
    document.getElementById("unrated-deliveries").textContent = requests.filter(item => ["delivered", "picked_up"].includes(item.status) && !item.rated).length;
}

async function loadLeaderboard() {
    const tbody = document.getElementById("leaderboard-body");

    try {
        const donor = await window.UniBiteAPI.AdminAPI.topDonor();

        if (!donor || donor.message) {
            tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;padding:20px;color:#999;">No donors yet.</td></tr>`;
            return;
        }

        tbody.innerHTML = `
            <tr>
                <td style="font-weight:bold;color:#ff8a3d;">1</td>
                <td>${escapeHtml(donor.name_lastname || "Student")}</td>
                <td><strong>${donor.portions_shared || 0}</strong> portions</td>
                <td>-</td>
                <td>-</td>
            </tr>
        `;
    } catch (error) {
        renderLocalLeaderboard(tbody);
    }
}

async function loadTopMeals() {
    const tbody = document.getElementById("top-meals-body");

    try {
        const meals = await window.UniBiteAPI.AdminAPI.topRatedMeals();
        const list = Array.isArray(meals) ? meals : [];

        if (!list.length) {
            tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;padding:20px;color:#999;">No rated meals yet.</td></tr>`;
            return;
        }

        tbody.innerHTML = list.map((meal, index) => `
            <tr>
                <td style="font-weight:bold;color:#ff8a3d;">${index + 1}</td>
                <td>${escapeHtml(meal.title || "Meal")}</td>
                <td>${escapeHtml(meal.cook_name || "Cook")}</td>
                <td><strong>${Number(meal.average_rating || 0).toFixed(1)}★</strong></td>
                <td>${meal.total_ratings || 0}</td>
            </tr>
        `).join("");
    } catch (error) {
        renderLocalTopMeals(tbody);
    }
}

function renderLocalLeaderboard(tbody) {
    const users = getUsers();
    const requests = getDeliveredRequests();
    const ratings = JSON.parse(localStorage.getItem("ratings") || "[]");

    const leaderboard = users.map(user => {
        const portions = requests.filter(request => normalizeUser(request.to) === normalizeUser(user.username)).length;
        const userRatings = ratings.filter(rating => normalizeUser(rating.to) === normalizeUser(user.username));
        return {
            username: user.username,
            portions,
            points: user.points || 0,
            avgRating: calculateAverageRating(userRatings),
            ratingsCount: userRatings.length
        };
    }).filter(user => user.portions > 0).sort((a, b) => b.portions - a.portions).slice(0, 10);

    if (!leaderboard.length) {
        tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;padding:20px;color:#999;">No donors yet.</td></tr>`;
        return;
    }

    tbody.innerHTML = leaderboard.map((user, index) => `
        <tr>
            <td style="font-weight:bold;color:#ff8a3d;">${index + 1}</td>
            <td>${escapeHtml(user.username)}</td>
            <td><strong>${user.portions}</strong> portions</td>
            <td>${user.points} pts</td>
            <td>${user.avgRating}★ (${user.ratingsCount})</td>
        </tr>
    `).join("");
}

function renderLocalTopMeals(tbody) {
    const meals = mealService.getAll();
    const ratings = JSON.parse(localStorage.getItem("ratings") || "[]");

    const topMeals = meals.map(meal => {
        const mealRatings = ratings.filter(rating => String(rating.mealId) === String(meal.id));
        return {
            title: meal.title,
            cook: meal.user,
            avgRating: calculateAverageRating(mealRatings),
            ratingsCount: mealRatings.length
        };
    }).filter(meal => meal.ratingsCount > 0).sort((a, b) => b.avgRating - a.avgRating).slice(0, 10);

    if (!topMeals.length) {
        tbody.innerHTML = `<tr><td colspan="5" style="text-align:center;padding:20px;color:#999;">No rated meals yet.</td></tr>`;
        return;
    }

    tbody.innerHTML = topMeals.map((meal, index) => `
        <tr>
            <td style="font-weight:bold;color:#ff8a3d;">${index + 1}</td>
            <td>${escapeHtml(meal.title)}</td>
            <td>${escapeHtml(meal.cook)}</td>
            <td><strong>${meal.avgRating}★</strong></td>
            <td>${meal.ratingsCount}</td>
        </tr>
    `).join("");
}

function loadRecentActivity() {
    const notifications = JSON.parse(localStorage.getItem("notifications") || "[]");
    const requests = JSON.parse(localStorage.getItem("requests") || "[]");
    const activity = [
        ...notifications.map(item => ({ icon: "📬", from: item.from || "System", message: item.message || "Notification", ts: item.ts || Date.now() })),
        ...requests.map(item => ({ icon: item.status === "delivered" ? "✓" : "→", from: item.from || "Student", message: `requested "${item.mealTitle || "meal"}"`, ts: item.ts || Date.now() }))
    ].sort((a, b) => b.ts - a.ts).slice(0, 15);

    const container = document.getElementById("recent-activity-list");
    if (!activity.length) {
        container.innerHTML = `<p style="text-align:center;color:#999;padding:20px;">No recent activity.</p>`;
        return;
    }

    container.innerHTML = activity.map(item => `
        <div class="activity-item">
            <span class="activity-icon">${item.icon}</span>
            <div class="activity-content">
                <p class="activity-message"><strong>${escapeHtml(item.from)}</strong>: ${escapeHtml(item.message)}</p>
                <p class="activity-time">${getTimeAgo(new Date(item.ts))}</p>
            </div>
        </div>
    `).join("");
}

function getDeliveredRequests() {
    const requests = JSON.parse(localStorage.getItem("requests") || "[]");
    return requests.filter(request => ["delivered", "picked_up"].includes(request.status));
}

function calculateAverageRating(ratings) {
    if (!ratings.length) return "0.0";
    const sum = ratings.reduce((total, rating) => total + Number(rating.stars || 0), 0);
    return (sum / ratings.length).toFixed(1);
}

function getTimeAgo(date) {
    const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
    if (seconds < 60) return "Just now";
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return minutes + "m ago";
    const hours = Math.floor(minutes / 60);
    if (hours < 24) return hours + "h ago";
    return Math.floor(hours / 24) + "d ago";
}

window.initAdmin = initAdmin;
