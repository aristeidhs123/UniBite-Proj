async function initRequests() {
    const list = document.getElementById("requests-list");
    if (!list) return;

    list.innerHTML = "<p>Loading requests...</p>";

    try {
        const cookId = window.UniBiteAPI?.getCurrentUserId ? window.UniBiteAPI.getCurrentUserId() : 1;
        const rows = await window.UniBiteAPI.RequestsAPI.getForCook(cookId);
        renderBackendRequests(rows || []);
    } catch (error) {
        renderLocalRequests();
    }
}

function renderBackendRequests(requests) {
    const list = document.getElementById("requests-list");

    if (!requests.length) {
        list.innerHTML = "<p>No requests for your meals yet.</p>";
        return;
    }

    list.innerHTML = "";

    requests.forEach(request => {
        const card = document.createElement("div");
        card.className = "request-card";
        card.innerHTML = `
            <h3>${escapeHtml(request.title || "Meal request")}</h3>
            <p><strong>From:</strong> ${escapeHtml(request.consumer_name || "Student")}</p>
            <p><strong>Email:</strong> ${escapeHtml(request.consumer_email || "-")}</p>
            <p><strong>Pickup:</strong> ${escapeHtml(request.pickUP_point || request.pickUp_point || "-")} at ${escapeHtml(request.pickUP_time || request.pickUp_time || "-")}</p>
            <p><strong>Status:</strong> ${escapeHtml(request.status || "pending")}</p>
            <div class="request-actions">
                ${request.status === "pending" ? `<button class="approve-btn">Approve</button><button class="reject-btn">Reject</button>` : ""}
                ${request.status === "approved" ? `<button class="pickup-btn">Picked up</button><button class="noshow-btn">No show</button>` : ""}
            </div>
        `;

        card.querySelector(".approve-btn")?.addEventListener("click", () => updateBackendRequest(request.requestID, "approve"));
        card.querySelector(".reject-btn")?.addEventListener("click", () => updateBackendRequest(request.requestID, "reject"));
        card.querySelector(".pickup-btn")?.addEventListener("click", () => updateBackendRequest(request.requestID, "pickedUp"));
        card.querySelector(".noshow-btn")?.addEventListener("click", () => updateBackendRequest(request.requestID, "noShow"));

        list.appendChild(card);
    });
}

async function updateBackendRequest(id, action) {
    try {
        if (action === "approve") await window.UniBiteAPI.RequestsAPI.approve(id);
        if (action === "reject") await window.UniBiteAPI.RequestsAPI.reject(id);
        if (action === "pickedUp") await window.UniBiteAPI.RequestsAPI.pickedUp(id);
        if (action === "noShow") await window.UniBiteAPI.RequestsAPI.noShow(id);
        showToast("Request updated.", "success");
        initRequests();
    } catch (error) {
        showToast(error.message || "Could not update request.", "error");
    }
}

function renderLocalRequests() {
    const list = document.getElementById("requests-list");
    const requests = JSON.parse(localStorage.getItem("requests") || "[]");
    const current = normalizeUser(window.CURRENT_USER);
    const myRequests = requests.filter(request => normalizeUser(request.to) === current || current === "admin");

    if (!myRequests.length) {
        list.innerHTML = "<p>No local requests yet.</p>";
        return;
    }

    list.innerHTML = "";

    myRequests.forEach(request => {
        const card = document.createElement("div");
        card.className = "request-card";
        card.innerHTML = `
            <h3>${escapeHtml(request.mealTitle || "Meal request")}</h3>
            <p><strong>From:</strong> ${escapeHtml(request.from || "Student")}</p>
            <p><strong>Status:</strong> ${escapeHtml(request.status || "pending")}</p>
            <div class="request-actions">
                ${request.status === "pending" ? `<button class="approve-btn">Approve</button><button class="reject-btn">Reject</button>` : ""}
                ${request.status === "approved" ? `<button class="pickup-btn">Picked up</button><button class="noshow-btn">No show</button>` : ""}
            </div>
        `;

        card.querySelector(".approve-btn")?.addEventListener("click", () => updateLocalRequest(request.id, "approved"));
        card.querySelector(".reject-btn")?.addEventListener("click", () => updateLocalRequest(request.id, "rejected"));
        card.querySelector(".pickup-btn")?.addEventListener("click", () => updateLocalRequest(request.id, "delivered"));
        card.querySelector(".noshow-btn")?.addEventListener("click", () => updateLocalRequest(request.id, "no_show"));

        list.appendChild(card);
    });
}

function updateLocalRequest(id, status) {
    const requests = JSON.parse(localStorage.getItem("requests") || "[]");
    const updated = requests.map(request => {
        if (String(request.id) !== String(id)) return request;
        return { ...request, status, delivered_ts: status === "delivered" ? Date.now() : request.delivered_ts };
    });
    localStorage.setItem("requests", JSON.stringify(updated));
    showToast("Request updated locally.", "success");
    renderLocalRequests();
}

function initRequestPage() {
    const detail = document.getElementById("request-detail") || document.getElementById("listing-detail");
    if (detail) detail.innerHTML = "<p>Open the Requests page to manage requests.</p>";
}

window.initRequests = initRequests;
window.initRequestPage = initRequestPage;
