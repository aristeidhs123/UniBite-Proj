
// σελιδα μηνυματων
async function initMessages() {
    const container = document.getElementById("messages-list");
    if (!container) return;

    const userId = window.UniBiteAPI?.getCurrentUserId?.();

    if (!userId) {
        container.innerHTML = "<p>Please log in to see messages.</p>";
        return;
    }

    container.innerHTML = "<p>Loading messages...</p>";

    try {
        const [notifications, messages] = await Promise.all([
            window.UniBiteAPI.NotificationsAPI.getForUser(userId),
            window.UniBiteAPI.MessagesAPI.getForUser(userId)
        ]);

        const items = [
            ...(notifications || []).map(row => ({
                id: row.notificationID,
                kind: "notification",
                title: row.listing_title || "Notification",
                from: row.actor_name || "System",
                message: row.message,
                requestID: row.request_id,
                listingID: row.listing_id,
                isRead: Number(row.is_read) === 1,
                createdAt: row.created_at
            })),
            ...(messages || []).map(row => ({
                id: row.messageID,
                kind: "message",
                title: "Message",
                from: row.sender_name || "User",
                message: row.message,
                requestID: row.request_id,
                isRead: Number(row.is_read) === 1,
                createdAt: row.created_at
            }))
        ].sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));

        if (items.length === 0) {
            container.innerHTML = "<p>No messages yet.</p>";
            return;
        }

        container.innerHTML = "";

        items.forEach(item => {
            const div = document.createElement("div");
            div.className = "message-item" + (item.isRead ? "" : " unread");

            div.innerHTML = `
                <div class="message-avatar"></div>
                <div class="message-content">
                    <div class="message-sender">
                        <strong>${escapeHtml(item.from || "System")}</strong>
                        <span class="message-meta">${escapeHtml(formatMessageDate(item.createdAt))}</span>
                    </div>
                    <h4 style="margin:4px 0;">${escapeHtml(item.title || "Message")}</h4>
                    <div class="message-text">${escapeHtml(item.message || "")}</div>
                    <div class="message-actions">
                        ${item.listingID ? `<button class="msg-btn view-listing-btn">View Listing</button>` : ""}
                        <button class="msg-btn view-notifications-btn">Open Notifications</button>
                    </div>
                </div>
            `;

            div.querySelector(".view-listing-btn")?.addEventListener("click", event => {
                event.stopPropagation();
                window.location.href = `listing.html?id=${encodeURIComponent(item.listingID)}`;
            });

            div.querySelector(".view-notifications-btn")?.addEventListener("click", event => {
                event.stopPropagation();
                window.location.href = "notifications.html";
            });

            container.appendChild(div);
        });

        if (notifications?.some(row => Number(row.is_read) === 0)) {
            await window.UniBiteAPI.NotificationsAPI.markAllRead(userId);
            if (typeof updateNotificationBadge === "function") updateNotificationBadge();
        }
    } catch (error) {
        container.innerHTML = `<p>Could not load messages: ${escapeHtml(error.message || "Server error")}</p>`;
    }
}

// μορφη ημερομηνιας μηνυματος
function formatMessageDate(value) {
    if (!value) return "";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value).replace("T", " ").slice(0, 16);
    return date.toLocaleString();
}

window.initMessages = initMessages;
