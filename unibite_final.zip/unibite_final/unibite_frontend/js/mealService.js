(function () {
    const STORAGE_KEY = "meals";

    // παλιο local storage parse
    function parseMeals(value) {
        try {
            const parsed = JSON.parse(value || "[]");
            return Array.isArray(parsed) ? parsed : [];
        } catch (error) {
            return [];
        }
    }

    // local γευματα
    function getAll() {
        return parseMeals(sessionStorage.getItem(STORAGE_KEY));
    }

    // αποθηκευση local γευματων
    function saveAll(meals) {
        sessionStorage.setItem(STORAGE_KEY, JSON.stringify(Array.isArray(meals) ? meals : []));
    }

    // local γευμα με id
    function getById(id) {
        return getAll().find(meal => String(meal.id) === String(id)) || null;
    }

    // local προσθηκη
    function add(meal) {
        const meals = getAll();
        meals.push(meal);
        saveAll(meals);
        return meal;
    }

    // local ενημερωση
    function update(meal) {
        const meals = getAll();
        const updated = meals.map(item => String(item.id) === String(meal.id) ? { ...item, ...meal } : item);
        saveAll(updated);
        return getById(meal.id);
    }

    // local διαγραφη
    function remove(id) {
        const filtered = getAll().filter(meal => String(meal.id) !== String(id));
        saveAll(filtered);
        return filtered;
    }

    // γευματα απο backend
    async function getAllRemote() {
        if (!window.UniBiteAPI) throw new Error("Backend API is not loaded");
        const rows = await window.UniBiteAPI.ListingsAPI.getAll();
        const list = Array.isArray(rows) ? rows : (rows.data || rows.listings || []);
        return list.map(window.UniBiteAPI.mapListingToMeal);
    }

    // γευμα απο backend
    async function getByIdRemote(id) {
        if (!window.UniBiteAPI) throw new Error("Backend API is not loaded");
        const row = await window.UniBiteAPI.ListingsAPI.getById(id);
        return window.UniBiteAPI.mapListingToMeal(row.data || row.listing || row);
    }

    // αποθηκευση στο backend
    async function saveRemote(meal, cookId) {
        if (!window.UniBiteAPI) throw new Error("Backend API is not loaded");
        const payload = window.UniBiteAPI.mapMealToListing(meal, cookId);

        if (meal.backendId || /^\d+$/.test(String(meal.id))) {
            const id = meal.backendId || meal.id;
            await window.UniBiteAPI.ListingsAPI.update(id, payload);
            return { ...meal, id: id, backendId: id };
        }

        const result = await window.UniBiteAPI.ListingsAPI.create(payload);
        const newId = result.listing_id || result.id || result.listingID;
        return { ...meal, id: newId, backendId: newId };
    }

    window.mealService = {
        getAll: getAll,
        getById: getById,
        saveAll: saveAll,
        add: add,
        update: update,
        remove: remove,
        getAllRemote: getAllRemote,
        getByIdRemote: getByIdRemote,
        saveRemote: saveRemote
    };
})();
