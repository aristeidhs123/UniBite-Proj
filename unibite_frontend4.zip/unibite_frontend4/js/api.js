(function () {
    const DEFAULT_BASE = "http://localhost:3000";

    function getBaseUrl() {
        return localStorage.getItem("UNIBITE_API_BASE") || DEFAULT_BASE;
    }

    async function request(path, method = "GET", data = null) {
        const options = {
            method,
            headers: {
                "Content-Type": "application/json"
            }
        };

        if (data !== null && data !== undefined) {
            options.body = JSON.stringify(data);
        }

        const response = await fetch(getBaseUrl() + path, options);
        let result = null;

        try {
            result = await response.json();
        } catch (error) {
            result = null;
        }

        if (!response.ok) {
            const message = result?.message || "Request failed";
            throw new Error(message);
        }

        return result;
    }

    function getCurrentUsername() {
        return localStorage.getItem("CURRENT_USER") || "";
    }

    function getCurrentUserId() {
        const saved = localStorage.getItem("CURRENT_USER_ID");
        if (saved) return Number(saved);

        const username = getCurrentUsername().replace("@", "").toLowerCase();

        const demoMap = {
            cooknwave: 1,
            chefanna: 2,
            foodie: 3,
            admin: 4
        };

        return demoMap[username] || 1;
    }

    function setCurrentUserId(id) {
        if (id !== null && id !== undefined) {
            localStorage.setItem("CURRENT_USER_ID", String(id));
        }
    }

    const ListingsAPI = {
        getAll: () => request("/listings"),
        create: (data) => request("/listings", "POST", data),
        update: (id, data) => request("/listings/" + id, "PATCH", data),
        remove: (id, cookId) => request("/listings/" + id, "DELETE", { cook_id: cookId })
    };

    const RequestsAPI = {
        create: (data) => request("/requests", "POST", data),
        getForCook: (cookId) => request("/requests/cook/" + cookId),
        approve: (id) => request("/requests/" + id + "/approve", "PATCH"),
        reject: (id) => request("/requests/" + id + "/reject", "PATCH"),
        pickedUp: (id) => request("/requests/" + id + "/picked-up", "PATCH"),
        noShow: (id) => request("/requests/" + id + "/no-show", "PATCH")
    };

    const RatingsAPI = {
        create: (data) => request("/ratings", "POST", data)
    };

    const UsersAPI = {
        register: (data) => request("/users/register", "POST", data),
        points: (id) => request("/users/" + id + "/points")
    };

    const AdminAPI = {
        monthlyPortions: () => request("/admin/stats/monthly-portions"),
        topDonor: () => request("/admin/leaderboard/top-donor"),
        topRatedMeals: () => request("/admin/leaderboard/top-rated-meals")
    };

    function mapListingToMeal(listing) {
        const id = listing.listingID ?? listing.listing_id ?? listing.id;
        const available = Number(listing.portions_available ?? listing.quantity ?? listing.portions_total ?? 0);
        const total = Number(listing.portions_total ?? available ?? 1);
        const createdAt = listing.created_at ? new Date(listing.created_at).getTime() : Date.now();
        const pickupPoint = listing.pickUP_point || listing.pickup_point || listing.pickupLocation || "";
        const pickupTime = listing.pickUP_time || listing.pickup_time || listing.pickupTime || "";

        return {
            id,
            backendId: id,
            cookId: listing.cook_id,
            title: listing.title || "Untitled meal",
            desc: listing.description || listing.desc || "",
            category: listing.category || "Lunch",
            quantity: available,
            totalQuantity: total,
            pickupLocation: pickupPoint,
            pickupTime: formatPickupTime(pickupTime),
            pickupRawTime: pickupTime,
            allergens: Array.isArray(listing.allergens) ? listing.allergens : [],
            image: listing.image || listing.photo || "",
            user: listing.cook_name || (listing.cook_id ? "Cook #" + listing.cook_id : "Unknown"),
            status: listing.status === "inactive" ? "available" : (listing.status || "available"),
            ts: createdAt,
            expiresAt: listing.expires_at || null
        };
    }

    function mapMealToListing(meal, cookId) {
        return {
            cook_id: Number(cookId),
            title: meal.title,
            description: meal.desc,
            pickup_point: meal.pickupLocation,
            pickup_time: normalizePickupTime(meal.pickupTime),
            portions_total: Number(meal.quantity || 1)
        };
    }

    function normalizePickupTime(value) {
        const text = String(value || "").trim();
        if (!text) return "";
        if (/^\d{4}-\d{2}-\d{2}/.test(text)) return text.replace("T", " ");
        if (/^\d{1,2}:\d{2}$/.test(text)) {
            const today = new Date().toISOString().slice(0, 10);
            return today + " " + text + ":00";
        }
        return text;
    }

    function formatPickupTime(value) {
        if (!value) return "";
        const text = String(value);
        if (text.includes("T")) return text.replace("T", " ").slice(0, 16);
        return text.slice(0, 16);
    }

    window.UniBiteAPI = {
        request,
        getBaseUrl,
        getCurrentUserId,
        setCurrentUserId,
        ListingsAPI,
        RequestsAPI,
        RatingsAPI,
        UsersAPI,
        AdminAPI,
        mapListingToMeal,
        mapMealToListing,
        normalizePickupTime
    };
})();
