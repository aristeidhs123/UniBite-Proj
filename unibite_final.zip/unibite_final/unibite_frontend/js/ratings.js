let ratingSelectedStars = 0;

// αποστολη αξιολογησης
async function submitRating(requestId, stars, comment = "") {
    if (!requestId || stars < 1 || stars > 5) {
        showToast("Invalid rating data.", "error");
        return;
    }

    try {
        await window.UniBiteAPI.RatingsAPI.create({
            request_id: Number(requestId),
            reviewer_id: window.UniBiteAPI.getCurrentUserId(),
            stars: Number(stars),
            description: comment
        });

        showToast(`Thank you! You rated this meal ${stars}★.`, "success");

        const modal = document.getElementById("rating-modal");
        if (modal) modal.style.display = "none";

        window.dispatchEvent(new CustomEvent("rating-submitted", {
            detail: { requestId, stars }
        }));
    } catch (error) {
        showToast(error.message || "Could not submit rating.", "error");
    }
}

// ποντοι απο rating
function calculatePointsFromRating(stars) {
    if (stars >= 4) return 2;
    if (stars >= 1) return 1;
    return 0;
}

// παλιο fallback rating
function hasUserRatedDelivery() {
    return false;
}

// penalty γινεται απο backend
function checkAndApplyRatingPenalties() {
    return;
}

// modal αξιολογησης
function initRatingModal() {
    if (document.getElementById("rating-modal")) return;

    const modal = document.createElement("div");
    modal.id = "rating-modal";
    modal.style.cssText = "display:none;position:fixed;inset:0;background:rgba(0,0,0,0.45);align-items:center;justify-content:center;z-index:2000;";
    modal.innerHTML = `
        <div style="background:white;padding:24px;border-radius:10px;max-width:420px;width:90%;">
            <h3>Rate this meal</h3>
            <div id="star-rating" style="margin:12px 0;">
                ${[1, 2, 3, 4, 5].map(i =>
                    `<span class="star" data-value="${i}" style="font-size:32px;cursor:pointer;color:#ddd;margin-right:8px;">★</span>`
                ).join("")}
            </div>
            <div id="selected-stars" style="margin-top:10px;font-weight:bold;color:#ff8a3d;">Select a rating</div>
            <textarea id="rating-comment" class="form-textarea" placeholder="Optional comment" style="width:100%;height:80px;margin-top:10px;padding:8px;border:1px solid #ddd;border-radius:4px;font-family:Arial;" maxlength="200"></textarea>
            <div style="margin-top:15px;display:flex;gap:10px;">
                <button id="submit-rating-btn" class="approve-btn" style="flex:1;padding:10px;">Submit Rating</button>
                <button id="cancel-rating-btn" class="reject-btn" style="flex:1;padding:10px;">Cancel</button>
            </div>
        </div>
    `;

    document.body.appendChild(modal);
    setupRatingStars();
}

// αστερια rating
function setupRatingStars() {
    ratingSelectedStars = 0;

    const stars = document.querySelectorAll(".star");

    stars.forEach(star => {
        star.addEventListener("mouseover", () => {
            const value = Number(star.dataset.value);
            stars.forEach((s, index) => {
                s.style.color = index < value ? "#ff8a3d" : "#ddd";
            });
        });

        star.addEventListener("click", () => {
            ratingSelectedStars = Number(star.dataset.value);
            document.getElementById("selected-stars").textContent = `Rating: ${ratingSelectedStars}★`;
            stars.forEach((s, index) => {
                s.style.color = index < ratingSelectedStars ? "#ff8a3d" : "#ddd";
            });
        });
    });

    const starsContainer = document.getElementById("star-rating");
    starsContainer.addEventListener("mouseleave", () => {
        stars.forEach((s, index) => {
            s.style.color = index < ratingSelectedStars ? "#ff8a3d" : "#ddd";
        });
    });

    const submitBtn = document.getElementById("submit-rating-btn");
    submitBtn.addEventListener("click", () => {
        const comment = document.getElementById("rating-comment").value;
        if (ratingSelectedStars === 0) {
            showToast("Please select a rating.", "warning");
            return;
        }
        submitRating(submitBtn.dataset.requestId, ratingSelectedStars, comment);
    });

    const cancelBtn = document.getElementById("cancel-rating-btn");
    cancelBtn.addEventListener("click", () => {
        document.getElementById("rating-modal").style.display = "none";
    });
}

// ανοιγμα rating modal
function showRatingModal(requestId) {
    initRatingModal();

    ratingSelectedStars = 0;
    const modal = document.getElementById("rating-modal");
    const submitBtn = document.getElementById("submit-rating-btn");

    submitBtn.dataset.requestId = requestId;
    modal.style.display = "flex";

    document.getElementById("rating-comment").value = "";
    document.querySelectorAll(".star").forEach(star => {
        star.style.color = "#ddd";
    });
    document.getElementById("selected-stars").textContent = "Select a rating";
}

window.submitRating = submitRating;
window.checkAndApplyRatingPenalties = checkAndApplyRatingPenalties;
window.showRatingModal = showRatingModal;
window.hasUserRatedDelivery = hasUserRatedDelivery;
window.calculatePointsFromRating = calculatePointsFromRating;
