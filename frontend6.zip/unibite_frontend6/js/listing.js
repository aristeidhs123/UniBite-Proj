function getQueryParam(name) {
    return new URLSearchParams(window.location.search).get(name);
}

async function initListingPage() {
    const detail = document.getElementById("listing-detail");
    if (!detail) return;

    const listingId = getQueryParam("id");
    detail.innerHTML = "<p>Loading listing...</p>";

    try {
        const meal = await mealService.getByIdRemote(listingId);
        renderListing(detail, meal);
    } catch (error) {
        detail.innerHTML = `<p>Could not load listing from backend: ${escapeHtml(error.message || "Server error")}</p>`;
    }
}

function renderListing(detail, meal) {
    if (!meal || String(meal.status || "") === "deleted") {
        detail.innerHTML = "<p>Listing not found.</p>";
        return;
    }

    const quantity = Number(meal.quantity == null ? 1 : meal.quantity);
    const expired = isMealExpired(meal);
    const unavailable = expired || quantity <= 0 || meal.status === "received";
    const owner = normalizeUser(meal.user) === normalizeUser(window.CURRENT_USER) || Number(meal.cookId) === Number(window.UniBiteAPI?.getCurrentUserId?.());
    const statusText = expired ? "Expired" : (quantity <= 0 ? "Out of stock" : (meal.status || "available"));

    detail.innerHTML = `
        <div class="meal-detail" style="max-width:700px;margin:0 auto;padding:20px;background:white;border-radius:8px;box-shadow:0 1px 3px rgba(0,0,0,0.1);">
            <div class="detail-image" style="background:#eee;height:300px;border-radius:8px;margin-bottom:20px;display:flex;align-items:center;justify-content:center;color:#999;overflow:hidden;">
                ${meal.image ? `<img src="${escapeHtml(meal.image)}" style="width:100%;height:100%;object-fit:cover;">` : "No Image"}
            </div>

            <h2 style="margin:15px 0 10px 0;font-size:28px;">${escapeHtml(meal.title)}</h2>
            <p style="color:#666;margin:5px 0 15px 0;font-size:15px;">${escapeHtml(meal.desc)}</p>

            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:12px;margin:20px 0;">
                <div><strong>Cook:</strong><br>${escapeHtml(meal.user || "Unknown")}</div>
                <div><strong>Portions:</strong><br>${quantity}</div>
                <div><strong>Pickup:</strong><br>${escapeHtml(meal.pickupLocation || "n/a")}</div>
                <div><strong>Time:</strong><br>${escapeHtml(meal.pickupTime || "n/a")}</div>
                <div><strong>Status:</strong><br>${escapeHtml(statusText)}</div>
            </div>

            ${Array.isArray(meal.allergens) && meal.allergens.length ? `<p style="color:#aa0000;"><strong>Allergens:</strong> ${escapeHtml(meal.allergens.join(", "))}</p>` : ""}

            <div id="listing-map" style="height:260px;border-radius:8px;margin:20px 0;"></div>

            <div style="display:flex;gap:10px;flex-wrap:wrap;">
                ${!owner ? `<button id="request-meal-btn" class="request-btn" ${unavailable ? "disabled" : ""}>${unavailable ? "Unavailable" : "Request Portion"}</button>` : ""}
                ${owner ? `<button id="edit-meal-btn" class="header-btn">Edit</button><button id="delete-meal-btn" class="header-btn danger-btn">Delete</button>` : ""}
                <a href="index.html" class="header-btn">Back to Feed</a>
            </div>
        </div>
    `;

    setupListingMap(meal);

    const requestBtn = document.getElementById("request-meal-btn");
    if (requestBtn && !unavailable) requestBtn.addEventListener("click", () => requestMeal(meal));

    const editBtn = document.getElementById("edit-meal-btn");
    if (editBtn) editBtn.addEventListener("click", () => {
        localStorage.setItem("editMealId", meal.id);
        window.location.href = "upload.html";
    });

    const deleteBtn = document.getElementById("delete-meal-btn");
    if (deleteBtn) deleteBtn.addEventListener("click", () => deleteMeal(meal));
}

async function requestMeal(meal) {
    if (!requireLogin()) return;

    const consumerId = window.UniBiteAPI?.getCurrentUserId ? window.UniBiteAPI.getCurrentUserId() : 1;

    try {
        await window.UniBiteAPI.RequestsAPI.create({
            listing_id: Number(meal.id),
            consumer_id: consumerId
        });

        showToast("Request sent.", "success");
    } catch (error) {
        showToast(error.message || "Could not send request.", "error");
    }
}

async function deleteMeal(meal) {
    if (!confirm("Delete this listing?")) return;

    try {
        const cookId = window.UniBiteAPI?.getCurrentUserId ? window.UniBiteAPI.getCurrentUserId() : meal.cookId;
        await window.UniBiteAPI.ListingsAPI.remove(meal.id, cookId);
        showToast("Listing deleted.", "success");
        window.location.href = "index.html";
    } catch (error) {
        showToast(error.message || "Could not delete listing.", "error");
    }
}

function setupListingMap(meal) {
    const mapEl = document.getElementById("listing-map");
    if (!mapEl || typeof L === "undefined") return;

    const coords = getListingCoordinates(meal.pickupLocation || "");
    const map = L.map(mapEl).setView(coords, 15);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {
        attribution: "&copy; OpenStreetMap"
    }).addTo(map);
    L.marker(coords).addTo(map).bindPopup(escapeHtml(meal.pickupLocation || "Pickup point")).openPopup();
}

function getListingCoordinates(location) {
    const text = String(location || "").toLowerCase();
    if (text.includes("εστία β") || text.includes("east dorm")) return [38.2485, 21.7380];
    if (text.includes("canteen") || text.includes("κυλικ")) return [38.2468, 21.7375];
    if (text.includes("library")) return [38.2478, 21.7350];
    return [38.2466, 21.7345];
}

function isMealExpired(meal) {
    if (meal.expiresAt) return new Date(meal.expiresAt).getTime() <= Date.now();
    return Date.now() - Number(meal.ts || 0) > 48 * 60 * 60 * 1000;
}

window.initListingPage = initListingPage;
