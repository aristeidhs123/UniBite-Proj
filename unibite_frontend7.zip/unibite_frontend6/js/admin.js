async function initAdmin() {
    const isAdmin = sessionStorage.getItem("CURRENT_USER_ROLE") === "admin";

    if (!isAdmin) {
        showToast("Access denied. Admin only.", "error");
        window.location.href = "index.html";
        return;
    }

    await loadTotalPortions();
    await loadTopDonor();
    await loadTopMeals();
}

async function loadTotalPortions() {
    const totalEl = document.getElementById("total-portions");
    if (!totalEl) return;

    try {
        const result = await window.UniBiteAPI.AdminAPI.monthlyPortions();
        totalEl.textContent =
            result?.total_portions_shared_last_month ??
            result?.totalPortions ??
            result?.total_portions ??
            result?.data?.total_portions_shared_last_month ??
            0;
    } catch (error) {
        totalEl.textContent = "Error";
    }
}

async function loadTopDonor() {
    const tbody = document.getElementById("top-donor-body");
    if (!tbody) return;

    try {
        const result = await window.UniBiteAPI.AdminAPI.topDonor();
        const donor = Array.isArray(result) ? result[0] : (result?.data || result);

        if (!donor || donor.message) {
            renderEmpty(tbody, 3, "No donor data yet.");
            return;
        }

        tbody.innerHTML = `
            <tr>
                <td>${escapeHtml(donor.name_lastname || donor.username || donor.name || "Student")}</td>
                <td><strong>${donor.portions_shared || donor.portionsGiven || donor.total_portions || 0}</strong></td>
                <td>${donor.points ?? "-"}</td>
            </tr>
        `;
    } catch (error) {
        renderEmpty(tbody, 3, "Could not load top donor from backend.");
    }
}

async function loadTopMeals() {
    const tbody = document.getElementById("top-meals-body");
    if (!tbody) return;

    try {
        const result = await window.UniBiteAPI.AdminAPI.topRatedMeals();
        const meals = Array.isArray(result) ? result : (result?.data || result?.meals || []);

        if (!meals.length) {
            renderEmpty(tbody, 5, "No rated meals yet.");
            return;
        }

        tbody.innerHTML = meals.map(function (meal, index) {
            return `
                <tr>
                    <td>${index + 1}</td>
                    <td>${escapeHtml(meal.title || meal.meal_title || "Meal")}</td>
                    <td>${escapeHtml(meal.cook_name || meal.cook || "Cook")}</td>
                    <td><strong>${Number(meal.average_rating || meal.avgRating || 0).toFixed(1)}★</strong></td>
                    <td>${meal.total_ratings || meal.ratingsCount || 0}</td>
                </tr>
            `;
        }).join("");
    } catch (error) {
        renderEmpty(tbody, 5, "Could not load top rated meals from backend.");
    }
}

function renderEmpty(tbody, colspan, message) {
    tbody.innerHTML = `
        <tr>
            <td colspan="${colspan}" class="empty-cell">${escapeHtml(message)}</td>
        </tr>
    `;
}

window.initAdmin = initAdmin;
