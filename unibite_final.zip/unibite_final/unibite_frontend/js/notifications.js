
let currentNotificationTab = "requests";
let notificationRequests = [];
let notificationMessages = [];

// σελιδα ειδοποιησεων
async function initNotifications() {
    const tabs = document.querySelectorAll(".tab-btn");
    tabs.forEach(btn => {
        btn.addEventListener("click", () => setNotificationsTab(btn.dataset.tab));
    });

    setNotificationsTab("requests");
    await refreshNotificationsPage();
}

// αλλαγη tab ειδοποιησεων
function setNotificationsTab(tab) {
    currentNotificationTab = tab;

    document.querySelectorAll(".tab-btn").forEach(btn => {
        btn.classList.toggle("active", btn.dataset.tab === tab);
    });

    const requestsPanel = document.getElementById("requests-list");
    const messagesPanel = document.getElementById("messages-list");

    if (requestsPanel) requestsPanel.style.display = tab === "requests" ? "block" : "none";
    if (messagesPanel) messagesPanel.style.display = tab === "messages" ? "block" : "none";
}

// ανανεωση ειδοποιησεων
async function refreshNotificationsPage() {
    await Promise.all([
        loadRequestsForNotifications(),
        loadMessagesForNotifications()
    ]);
}

// αιτηματα για notifications
async function loadRequestsForNotifications() {
    const container = document.getElementById("requests-list");
    if (!container) return;

    const userId = window.UniBiteAPI?.getCurrentUserId?.();

    if (!userId) {
        container.innerHTML = "<p style='text-align:center;padding:20px;color:#999;'>Please log in to see requests.</p>";
        return;
    }

    container.innerHTML = "<p style='text-align:center;padding:20px;color:#666;'>Loading requests...</p>";

    try {
        const [cookRows, consumerRows] = await Promise.all([
            window.UniBiteAPI.RequestsAPI.getForCook(userId),
            window.UniBiteAPI.RequestsAPI.getForConsumer(userId)
        ]);

        notificationRequests = [
            ...(cookRows || []).map(row => normalizeRequestRow(row, "cook")),
            ...(consumerRows || []).map(row => normalizeRequestRow(row, "consumer"))
        ].sort((a, b) => new Date(b.created_at || 0) - new Date(a.created_at || 0));

        renderNotificationRequests(container);
    } catch (error) {
        container.innerHTML = `<p style='text-align:center;padding:20px;color:#666;'>Could not load requests: ${escapeHtml(error.message || "Server error")}</p>`;
    }
}

// ιδια μορφη αιτηματος
function normalizeRequestRow(row, role) {
    return {
        ...row,
        viewRole: role,
        requestID: row.requestID,
        listingID: row.listingID,
        title: row.title || "Meal request",
        otherUser: role === "cook"
            ? (row.consumer_name || "Student")
            : (row.cook_name || "Cook"),
        otherEmail: role === "cook"
            ? (row.consumer_email || "")
            : (row.cook_email || ""),
        pickupPoint: row.pickUP_point || row.pickup_point || row.pickUp_point || "-",
        pickupTime: row.pickUP_time || row.pickup_time || row.pickUp_time || "-"
    };
}

// εμφανιση αιτηματων
function renderNotificationRequests(container) {
    if (notificationRequests.length === 0) {
        container.innerHTML = "<p style='text-align:center;padding:20px;color:#999;'>No requests yet.</p>";
        return;
    }

    container.innerHTML = "";

    notificationRequests.forEach(req => {
        const box = document.createElement("div");
        box.className = "notification-box request-item";
        box.style.cursor = "pointer";

        const actionButtons = [];

        if (req.viewRole === "cook" && req.status === "pending") {
            actionButtons.push(`<button class="approve-btn" data-action="approve">Accept</button>`);
            actionButtons.push(`<button class="reject-btn" data-action="reject">Reject</button>`);
        }

        if (req.viewRole === "cook" && req.status === "approved") {
            actionButtons.push(`<button class="approve-btn" data-action="pickedUp">Picked up</button>`);
            actionButtons.push(`<button class="reject-btn" data-action="noShow">No show</button>`);
        }

        if (req.viewRole === "consumer" && req.status === "picked_up" && !req.ratingID) {
            actionButtons.push(`<button class="approve-btn" data-action="rate">Rate meal</button>`);
        }

        actionButtons.push(`<button class="delivered-btn" data-action="view">View Listing</button>`);

        box.innerHTML = `
            <div class="request-header" style="display:flex;justify-content:space-between;align-items:center;">
                <div style="flex:1;">
                    <h4 style="margin:0 0 6px 0;">${escapeHtml(req.title)}</h4>
                    <p style="margin:2px 0;font-size:14px;"><strong>${req.viewRole === "cook" ? "From" : "Cook"}:</strong> ${escapeHtml(req.otherUser)}</p>
                    <p style="margin:2px 0;font-size:14px;"><strong>Status:</strong> <span class="status-badge ${escapeHtml(req.status)}">${escapeHtml(req.status)}</span></p>
                    <p style="margin:2px 0;font-size:13px;color:#666;"><strong>Pickup:</strong> ${escapeHtml(req.pickupPoint)} at ${escapeHtml(formatBackendDate(req.pickupTime))}</p>
                </div>
            </div>
            <div class="notification-actions" style="margin-top:10px;display:flex;gap:8px;flex-wrap:wrap;">
                ${actionButtons.join("")}
            </div>
        `;

        box.addEventListener("click", event => {
            if (event.target.closest("button")) return;
            showRequestDetail(req);
        });

        box.querySelectorAll("button[data-action]").forEach(button => {
            button.addEventListener("click", event => {
                event.stopPropagation();
                handleRequestAction(req, button.dataset.action);
            });
        });

        container.appendChild(box);
    });

    showRequestDetail(notificationRequests[0]);
}

// ενεργειες αιτηματος
async function handleRequestAction(req, action) {
    try {
        if (action === "approve") await window.UniBiteAPI.RequestsAPI.approve(req.requestID);
        if (action === "reject") await window.UniBiteAPI.RequestsAPI.reject(req.requestID);
        if (action === "pickedUp") await window.UniBiteAPI.RequestsAPI.pickedUp(req.requestID);
        if (action === "noShow") await window.UniBiteAPI.RequestsAPI.noShow(req.requestID);
        if (action === "rate") {
            showRatingModal(req.requestID);
            return;
        }
        if (action === "view") {
            openListingPage(req.listingID);
            return;
        }

        showToast("Request updated.", "success");
        await refreshNotificationsPage();
    } catch (error) {
        showToast(error.message || "Could not update request.", "error");
    }
}

// μηνυματα και ειδοποιησεις
async function loadMessagesForNotifications() {
    const container = document.getElementById("messages-list");
    if (!container) return;

    const userId = window.UniBiteAPI?.getCurrentUserId?.();

    if (!userId) {
        container.innerHTML = "<p style='text-align:center;padding:20px;color:#999;'>Please log in to see messages.</p>";
        return;
    }

    container.innerHTML = "<p style='text-align:center;padding:20px;color:#666;'>Loading messages...</p>";

    try {
        const [notifications, messages] = await Promise.all([
            window.UniBiteAPI.NotificationsAPI.getForUser(userId),
            window.UniBiteAPI.MessagesAPI.getForUser(userId)
        ]);

        notificationMessages = [
            ...(notifications || []).map(row => ({
                kind: "notification",
                id: row.notificationID,
                requestID: row.request_id,
                listingID: row.listing_id,
                title: row.listing_title || "Notification",
                from: row.actor_name || "System",
                message: row.message,
                type: row.type,
                isRead: Number(row.is_read) === 1,
                createdAt: row.created_at
            })),
            ...(messages || []).map(row => ({
                kind: "message",
                id: row.messageID,
                requestID: row.request_id,
                title: "Message",
                from: row.sender_name || "User",
                message: row.message,
                type: "message",
                isRead: Number(row.is_read) === 1,
                createdAt: row.created_at
            }))
        ].sort((a, b) => new Date(b.createdAt || 0) - new Date(a.createdAt || 0));

        renderNotificationMessages(container);

        if (notifications?.some(row => Number(row.is_read) === 0)) {
            await window.UniBiteAPI.NotificationsAPI.markAllRead(userId);
            if (typeof updateNotificationBadge === "function") updateNotificationBadge();
        }
    } catch (error) {
        container.innerHTML = `<p style='text-align:center;padding:20px;color:#666;'>Could not load messages: ${escapeHtml(error.message || "Server error")}</p>`;
    }
}

// εμφανιση μηνυματων
function renderNotificationMessages(container) {
    if (notificationMessages.length === 0) {
        container.innerHTML = "<p style='text-align:center;padding:20px;color:#999;'>No messages yet.</p>";
        return;
    }

    container.innerHTML = "";

    notificationMessages.forEach(note => {
        const box = document.createElement("div");
        box.className = "notification-box message-item";
        box.style.cursor = "pointer";

        box.innerHTML = `
            <div class="request-header" style="display:flex;justify-content:space-between;align-items:center;">
                <div style="flex:1;">
                    <h4 style="margin:0 0 6px 0;">${escapeHtml(note.title || "Message")}</h4>
                    <p style="margin:2px 0;font-size:14px;"><strong>From:</strong> ${escapeHtml(note.from || "System")}</p>
                    <p style="margin:2px 0;font-size:14px;"><strong>Type:</strong> ${escapeHtml(note.type || "message")}</p>
                    <p style="margin:2px 0;font-size:12px;color:#666;">${escapeHtml(formatBackendDate(note.createdAt))}</p>
                </div>
            </div>
            <div class="message-text">${escapeHtml(note.message || "")}</div>
            <div class="notification-actions" style="margin-top:10px;">
                ${note.requestID ? `<button class="approve-btn" data-action="viewRequest">View Request</button>` : ""}
                ${note.listingID ? `<button class="delivered-btn" data-action="viewListing">View Listing</button>` : ""}
            </div>
        `;

        box.addEventListener("click", event => {
            if (event.target.closest("button")) return;
            showMessageDetail(note);
        });

        box.querySelector("[data-action='viewRequest']")?.addEventListener("click", event => {
            event.stopPropagation();
            const req = notificationRequests.find(item => Number(item.requestID) === Number(note.requestID));
            setNotificationsTab("requests");
            if (req) showRequestDetail(req);
        });

        box.querySelector("[data-action='viewListing']")?.addEventListener("click", event => {
            event.stopPropagation();
            openListingPage(note.listingID);
        });

        container.appendChild(box);
    });
}

// λεπτομερειες αιτηματος
function showRequestDetail(req) {
    const detailContainer = document.getElementById("detail-content");
    if (!detailContainer || !req) return;

    detailContainer.innerHTML = `
        <div class="meal-detail">
            <h2 style="margin:0 0 12px 0;">${escapeHtml(req.title)}</h2>
            <p><strong>${req.viewRole === "cook" ? "Requested by" : "Cook"}:</strong> ${escapeHtml(req.otherUser)}</p>
            ${req.otherEmail ? `<p><strong>Email:</strong> ${escapeHtml(req.otherEmail)}</p>` : ""}
            <p><strong>Status:</strong> <span class="status-badge ${escapeHtml(req.status)}">${escapeHtml(req.status)}</span></p>
            <p><strong>Pickup:</strong> ${escapeHtml(req.pickupPoint)} at ${escapeHtml(formatBackendDate(req.pickupTime))}</p>
            <p><strong>Ordered:</strong> ${escapeHtml(formatBackendDate(req.created_at))}</p>
            <div style="display:flex;gap:10px;margin-top:15px;flex-wrap:wrap;">
                <button id="detail-view-listing-btn" class="approve-btn">View Full Listing</button>
                ${req.viewRole === "consumer" && req.status === "picked_up" && !req.ratingID ? `<button id="detail-rate-btn" class="delivered-btn">Rate Meal</button>` : ""}
            </div>
        </div>
    `;

    document.getElementById("detail-view-listing-btn")?.addEventListener("click", () => {
        openListingPage(req.listingID);
    });

    document.getElementById("detail-rate-btn")?.addEventListener("click", () => {
        showRatingModal(req.requestID);
    });
}

// λεπτομερειες μηνυματος
function showMessageDetail(note) {
    const detailContainer = document.getElementById("detail-content");
    if (!detailContainer || !note) return;

    detailContainer.innerHTML = `
        <div class="meal-detail">
            <h2 style="margin:0 0 12px 0;">Message Details</h2>
            <p><strong>From:</strong> ${escapeHtml(note.from || "System")}</p>
            <p><strong>Type:</strong> ${escapeHtml(note.type || "message")}</p>
            <p style="margin:8px 0;"><strong>Message:</strong> ${escapeHtml(note.message || "")}</p>
            <p style="margin:8px 0;color:#666;"><strong>Received:</strong> ${escapeHtml(formatBackendDate(note.createdAt))}</p>
            <div style="display:flex;gap:10px;margin-top:15px;flex-wrap:wrap;">
                ${note.requestID ? `<button id="message-view-request-btn" class="approve-btn">View Request</button>` : ""}
                ${note.listingID ? `<button id="message-view-listing-btn" class="delivered-btn">View Listing</button>` : ""}
            </div>
        </div>
    `;

    document.getElementById("message-view-request-btn")?.addEventListener("click", () => {
        const req = notificationRequests.find(item => Number(item.requestID) === Number(note.requestID));
        setNotificationsTab("requests");
        if (req) showRequestDetail(req);
    });

    document.getElementById("message-view-listing-btn")?.addEventListener("click", () => {
        openListingPage(note.listingID);
    });
}

// ανοιγμα αγγελιας
function openListingPage(listingId) {
    if (!listingId) return;
    window.location.href = `listing.html?id=${encodeURIComponent(listingId)}`;
}

// μορφη ημερομηνιας backend
function formatBackendDate(value) {
    if (!value) return "-";
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) return String(value).replace("T", " ").slice(0, 16);
    return date.toLocaleString();
}

window.initNotifications = initNotifications;
