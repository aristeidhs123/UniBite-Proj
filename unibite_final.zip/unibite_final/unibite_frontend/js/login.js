// ελεγχος email
function isValidEmail(email) {
    return /^\S+@\S+\.\S+$/.test(String(email || "").trim());
}

// login και εγγραφη
function initLogin() {
    const form = document.getElementById("login-form");
    if (!form) return;

    const tabLogin = document.getElementById("tab-login");
    const tabSignup = document.getElementById("tab-signup");
    const signupExtra = document.getElementById("signup-extra");
    const submitBtn = document.getElementById("submit-auth");
    const passwordInput = document.getElementById("password");
    const confirmPasswordInput = document.getElementById("confirm-password");
    const togglePasswordBtn = document.getElementById("toggle-password");

    let mode = "login";

    // αλλαγη login/signup
    function setMode(nextMode) {
        mode = nextMode;
        signupExtra.classList.toggle("hidden", mode === "login");
        submitBtn.textContent = mode === "login" ? "Login" : "Sign up";
        tabLogin.classList.toggle("active", mode === "login");
        tabSignup.classList.toggle("active", mode === "signup");
    }

    tabLogin?.addEventListener("click", () => setMode("login"));
    tabSignup?.addEventListener("click", () => setMode("signup"));

    togglePasswordBtn?.addEventListener("click", () => {
        const show = passwordInput.type === "password";
        passwordInput.type = show ? "text" : "password";
        if (confirmPasswordInput) confirmPasswordInput.type = passwordInput.type;
        togglePasswordBtn.textContent = show ? "Hide" : "Show";
    });

    setMode("login");

    form.addEventListener("submit", async event => {
        event.preventDefault();

        let username = (document.getElementById("username").value || "").trim();
        const password = document.getElementById("password").value || "";

        if (!username || !password) {
            showToast("Please fill all required fields.", "warning");
            return;
        }

        if (mode === "login") {
            try {
                const result = await window.UniBiteAPI.UsersAPI.login({
                    identifier: username,
                    password
                });
                const user = result.user;

                sessionStorage.setItem("CURRENT_USER", user.email);
                sessionStorage.setItem("CURRENT_USER_NAME", user.name_lastname || user.email);
                sessionStorage.setItem("CURRENT_USER_EMAIL", user.email);
                sessionStorage.setItem("CURRENT_USER_ID", String(user.userID || user.user_id));
                sessionStorage.setItem("CURRENT_USER_ROLE", user.role);
                sessionStorage.setItem("CURRENT_USER_POINTS", String(user.points));
                sessionStorage.setItem("CURRENT_USER_BIO", user.bio || "");
                sessionStorage.setItem("CURRENT_USER_PROFILE_IMAGE", user.profile_image || "");
                window.CURRENT_USER = user.email;

                showToast("Login successful.", "success");
                window.location.href = user.role === "admin" ? "admin.html" : "index.html";
            } catch (error) {
                showToast(error.message || "Invalid credentials.", "error");
            }
            return;
        }

        const email = (document.getElementById("email").value || "").trim();
        const confirm = document.getElementById("confirm-password").value || "";

        if (!isValidEmail(email)) {
            showToast("Please enter a valid email.", "warning");
            return;
        }

        if (password.length < 4) {
            showToast("Password must be at least 4 characters.", "warning");
            return;
        }

        if (password !== confirm) {
            showToast("Passwords do not match.", "warning");
            return;
        }

        try {
            const result = await window.UniBiteAPI.UsersAPI.register({
                name_lastname: username.replace("@", ""),
                email,
                password
            });

            sessionStorage.setItem("CURRENT_USER", result.email);
            sessionStorage.setItem("CURRENT_USER_NAME", result.name_lastname || result.email);
            sessionStorage.setItem("CURRENT_USER_EMAIL", result.email);
            sessionStorage.setItem("CURRENT_USER_ID", String(result.userID || result.user_id));
            sessionStorage.setItem("CURRENT_USER_ROLE", result.role || "student");
            sessionStorage.setItem("CURRENT_USER_POINTS", String(result.points ?? 5));
            sessionStorage.setItem("CURRENT_USER_BIO", result.bio || "");
            sessionStorage.setItem("CURRENT_USER_PROFILE_IMAGE", result.profile_image || "");
            window.CURRENT_USER = result.email;

            showToast("Account created and logged in.", "success");
            window.location.href = "index.html";
        } catch (error) {
            showToast(error.message || "Could not create account.", "error");
        }
    });
}

window.initLogin = initLogin;
