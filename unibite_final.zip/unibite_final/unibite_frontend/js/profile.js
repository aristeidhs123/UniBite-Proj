
let selectedProfilePhoto = null;
let selectedProfilePhotoFile = null;

// αρχικη σελιδα προφιλ
function initProfile() {
    renderProfileSummary();
    loadProfileEditForm();
    loadUserListings();
    loadUserOrders();
    initProfileTabs();
    window.addEventListener("rating-submitted", loadUserOrders);

    const editBtn = document.getElementById("edit-profile-btn");
    const cancelBtn = document.getElementById("cancel-profile-btn");
    const photoInput = document.getElementById("profile-photo-input");
    const form = document.getElementById("profile-form");

    if (editBtn) {
        editBtn.addEventListener("click", () => {
            toggleProfileEditPanel(true);
        });
    }

    if (cancelBtn) {
        cancelBtn.addEventListener("click", () => {
            toggleProfileEditPanel(false);
        });
    }

    if (photoInput) {
        photoInput.addEventListener("change", handleProfilePhotoChange);
    }

    if (form) {
        form.addEventListener("submit", (e) => {
            e.preventDefault();
            saveProfile();
        });
    }
}

// στοιχεια προφιλ
function renderProfileSummary() {
    const usernameEl = document.getElementById("profile-username");
    const pointsEl = document.getElementById("profile-points");
    const emailDisplay = document.getElementById("profile-email-display");
    const locationDisplay = document.getElementById("profile-location-display");
    const displayNameEl = document.getElementById("profile-display-name");
    const avatarImg = document.getElementById("profile-avatar-image");
    const avatarInitials = document.getElementById("profile-avatar-initials");

    const profile = getCurrentUserProfile();
    const username = profile?.username || window.CURRENT_USER || "";
    const displayName = profile?.displayName || username;
    const email = profile?.email || "-";
    const location = profile?.location || "-";
    const photo = profile?.photo || "";

    if (displayNameEl) {
        displayNameEl.textContent = displayName;
    }
    if (usernameEl) {
        usernameEl.textContent = username;
    }
    if (pointsEl) {
        pointsEl.textContent = profile?.points ?? 0;
    }
    if (emailDisplay) {
        emailDisplay.textContent = `Email: ${email}`;
    }
    if (locationDisplay) {
        locationDisplay.textContent = `Location: ${location}`;
    }

    if (photo && avatarImg) {
        avatarImg.src = photo;
        avatarImg.style.display = "block";
        avatarInitials.style.display = "none";
    } else {
        if (avatarImg) avatarImg.style.display = "none";
        if (avatarInitials) {
            avatarInitials.style.display = "block";
            avatarInitials.textContent = getInitials(displayName || username);
        }
    }
}

// φορμα edit προφιλ
function loadProfileEditForm() {
    const displayNameInput = document.getElementById("profile-display-name-input");
    const emailInput = document.getElementById("profile-email-input");
    const locationInput = document.getElementById("profile-location-input");
    const profilePhotoPreviewWrap = document.getElementById("profile-photo-preview-wrap");
    const profilePhotoPreview = document.getElementById("profile-photo-preview");

    const profile = getCurrentUserProfile();
    const displayName = profile?.displayName || profile?.username || window.CURRENT_USER || "";

    if (displayNameInput) {
        displayNameInput.value = displayName;
    }
    if (emailInput) {
        emailInput.value = profile?.email || "";
    }
    if (locationInput) {
        locationInput.value = profile?.location || "";
    }

    selectedProfilePhoto = profile?.photo || null;
    if (selectedProfilePhoto && profilePhotoPreview && profilePhotoPreviewWrap) {
        profilePhotoPreview.src = selectedProfilePhoto;
        profilePhotoPreviewWrap.style.display = "block";
    } else if (profilePhotoPreviewWrap) {
        profilePhotoPreviewWrap.style.display = "none";
    }

    toggleProfileEditPanel(false);
}

// ανοιγμα edit panel
function toggleProfileEditPanel(show) {
    const panel = document.getElementById("profile-edit-panel");
    if (!panel) return;
    if (typeof show === "boolean") {
        panel.classList.toggle("hidden", !show);
    } else {
        panel.classList.toggle("hidden");
    }
}

// preview φωτογραφιας
function handleProfilePhotoChange(event) {
    const file = event.target.files[0];
    const previewWrap = document.getElementById("profile-photo-preview-wrap");
    const preview = document.getElementById("profile-photo-preview");

    if (!file || !preview || !previewWrap) {
        return;
    }

    selectedProfilePhotoFile = file;

    const reader = new FileReader();
    reader.onload = () => {
        selectedProfilePhoto = reader.result;
        preview.src = reader.result;
        previewWrap.style.display = "block";
    };
    reader.readAsDataURL(file);
}

// αρχικα χρηστη
function getInitials(text) {
    const words = String(text).trim().split(/\s+/);
    if (words.length === 0) return "?";
    if (words.length === 1) return words[0].charAt(0).toUpperCase();
    return `${words[0].charAt(0)}${words[1].charAt(0)}`.toUpperCase();
}

// αποθηκευση προφιλ
async function saveProfile() {
    const displayNameInput = document.getElementById("profile-display-name-input");
    const emailInput = document.getElementById("profile-email-input");
    const locationInput = document.getElementById("profile-location-input");
    const saveBtn = document.getElementById("save-profile-btn");

    if (!displayNameInput || !emailInput || !locationInput) {
        return;
    }

    const profile = getCurrentUserProfile();
    if (!profile) return;

    const updated = {
        ...profile,
        displayName: displayNameInput.value.trim() || profile.username,
        email: emailInput.value.trim(),
        location: locationInput.value.trim(),
        photo: selectedProfilePhoto || profile.photo || ""
    };

    const userId = window.UniBiteAPI?.getCurrentUserId ? window.UniBiteAPI.getCurrentUserId() : profile.backendId;

    if (!userId) {
        showToast("Could not find current user id.", "error");
        return;
    }

    if (saveBtn) saveBtn.disabled = true;

    try {
        let finalProfileImage = profile.photo || "";

        if (selectedProfilePhotoFile) {
            finalProfileImage = await window.UniBiteAPI.UsersAPI.uploadProfileImage(selectedProfilePhotoFile);
}
        const result = await window.UniBiteAPI.UsersAPI.updateProfile(userId, {
            name_lastname: updated.displayName,
            email: updated.email,
            bio: updated.location,
            profile_image: finalProfileImage
        });

        const user = result.user || {};
        updateUserProfile({
            ...updated,
            displayName: user.name_lastname || updated.displayName,
            email: user.email || updated.email,
            location: user.bio ?? updated.location,
            photo: user.profile_image || updated.photo,
            points: user.points ?? updated.points,
            role: user.role || updated.role,
            backendId: user.userID || user.user_id || userId
        });

        showToast("Profile updated successfully.", "success");
        renderProfileSummary();
        loadProfileEditForm();
    } catch (error) {
        showToast(error.message || "Could not update profile.", "error");
    } finally {
        if (saveBtn) saveBtn.disabled = false;
    }
}

// γευματα που προσφερω
async function loadUserListings() {
    const container = document.getElementById("profile-listings");
    if (!container) return;
    container.innerHTML = "<p style='text-align:center;padding:20px;color:#666;'>Loading your meals...</p>";

    let userMeals = [];

    try {
        const cookId = window.UniBiteAPI?.getCurrentUserId ? window.UniBiteAPI.getCurrentUserId() : null;
        const meals = await mealService.getAllRemote();
        userMeals = meals.filter(meal => Number(meal.cookId) === Number(cookId) && String(meal.status || "") !== "deleted");
    } catch (error) {
        container.innerHTML = `<p style='text-align:center;padding:20px;color:#666;'>Could not load your meals from backend.</p>`;
        return;
    }

    if (userMeals.length === 0) {
        container.innerHTML = "<p style='text-align:center;padding:20px;color:#666;'>No cooked meals yet. Upload a meal!</p>";
        return;
    }

    userMeals.sort((a, b) => (Number(b.ts || b.id || 0) - Number(a.ts || a.id || 0)));

    userMeals.forEach(meal => {
        const div = document.createElement("div");
        div.className = "listing";
        div.dataset.id = meal.id;
        const ratingText = meal.totalRatings > 0
            ? `${Number(meal.averageRating || 0).toFixed(1)}★ (${meal.totalRatings})`
            : "No ratings yet";

        div.innerHTML = `
            <div class="listing-row" style="display:flex;gap:12px;align-items:center;">
                <div class="listing-thumb" style="width:140px;height:140px;border-radius:12px;overflow:hidden;background:#eee;flex-shrink:0;">
                    ${meal.image ? `<img src="${meal.image}" style="width:100%;height:100%;object-fit:cover;">` : `<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:#999">No Image</div>`}
                </div>
                <div style="flex:1">
                    <h3 style="margin:0 0 6px 0">${escapeHtml(meal.title)}</h3>
                    <p style="margin:0 0 6px 0;color:#555">${escapeHtml(meal.desc)}</p>
                    <small class="listing-category">Category: ${escapeHtml(meal.category || "n/a")}</small>
                    <div style="margin-top:6px;font-size:13px;color:#666;">
                        Portions: ${Number(meal.quantity == null ? 1 : meal.quantity)} &middot; Pickup: ${escapeHtml(meal.pickupLocation || "n/a")} at ${escapeHtml(meal.pickupTime || "n/a")}
                    </div>
                    <div style="margin-top:6px;font-size:13px;color:#666;">
                        <strong>Rating:</strong> ${escapeHtml(ratingText)}
                    </div>
                    <div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
                        <button class="edit-btn msg-btn">Edit</button>
                        <button class="delete-btn msg-btn">Delete</button>
                        <button class="toggle-btn msg-btn">${meal.status === "received" ? "Mark Available" : "Mark Received"}</button>
                        <button class="view-btn msg-btn">View</button>
                    </div>
                    <div style="margin-top:6px;font-size:13px;color:#666;">
                        <strong>Status:</strong> ${escapeHtml(meal.status || "available")}
                    </div>
                </div>
            </div>
        `;

        const editBtn = div.querySelector(".edit-btn");
        const deleteBtn = div.querySelector(".delete-btn");
        const toggleBtn = div.querySelector(".toggle-btn");
        const viewBtn = div.querySelector(".view-btn");

        if (editBtn) editBtn.addEventListener("click", (e) => { e.stopPropagation(); sessionStorage.setItem("editMealId", meal.id); window.location.href = "upload.html"; });
        if (deleteBtn) deleteBtn.addEventListener("click", async (e) => { e.stopPropagation(); await deleteMeal(meal.id); loadUserListings(); });
        if (toggleBtn) toggleBtn.style.display = "none";
        if (viewBtn) viewBtn.addEventListener("click", (e) => { e.stopPropagation(); openListingPage(meal.id); });

        div.addEventListener("click", (e) => { if (e.target.closest("button")) return; openListingPage(meal.id); });

        container.appendChild(div);
    });
}

// tabs προφιλ
function initProfileTabs() {
    const tabs = document.querySelectorAll(".profile-tab-btn");
    tabs.forEach(btn => {
        btn.addEventListener("click", () => {
            setProfileTab(btn.dataset.tab);
        });
    });
    setProfileTab("meals");
}

// αλλαγη tab προφιλ
function setProfileTab(tab) {
    document.querySelectorAll(".profile-tab-btn").forEach(btn => {
        btn.classList.toggle("active", btn.dataset.tab === tab);
    });
    const mealsPanel = document.getElementById("profile-meals-panel");
    const ordersPanel = document.getElementById("profile-orders-panel");
    if (mealsPanel) {
        mealsPanel.classList.toggle("hidden", tab !== "meals");
    }
    if (ordersPanel) {
        ordersPanel.classList.toggle("hidden", tab !== "orders");
    }
}

// γευματα που παρηγγειλα
async function loadUserOrders() {
    const container = document.getElementById("profile-orders");
    if (!container) return;
    container.innerHTML = "<p style='text-align:center;padding:20px;color:#666;'>Loading your orders...</p>";

    let userOrders = [];

    try {
        const consumerId = window.UniBiteAPI?.getCurrentUserId ? window.UniBiteAPI.getCurrentUserId() : null;
        userOrders = await window.UniBiteAPI.RequestsAPI.getForConsumer(consumerId);
    } catch (error) {
        container.innerHTML = "<p style='text-align:center;padding:20px;color:#666;'>Could not load your orders from backend.</p>";
        return;
    }

    if (userOrders.length === 0) {
        container.innerHTML = "<p style='text-align:center;padding:20px;color:#666;'>No orders yet.</p>";
        return;
    }

    userOrders.forEach(req => {
        const div = document.createElement("div");
        div.className = "listing profile-order-card";
        div.dataset.id = req.listingID;
        const orderDate = formatProfileDate(req.created_at, "date");
        const pickupTime = formatProfileDate(req.pickUP_time || req.pickup_time, "datetime");
        const canRate = req.status === "picked_up" && !req.ratingID;
        div.innerHTML = `
            <h4>${escapeHtml(req.title || req.mealTitle || "Meal")}</h4>
            <p style="margin:4px 0;"><strong>Cook:</strong> ${escapeHtml(req.cook_name || req.to || "-")}</p>
            <p style="margin:4px 0;"><strong>Status:</strong> ${escapeHtml(req.status || "pending")}</p>
            <p style="margin:4px 0;"><strong>Pickup:</strong> ${escapeHtml(req.pickUP_point || req.pickup_point || "-")} at ${escapeHtml(pickupTime)}</p>
            <p class="order-status">Ordered on ${escapeHtml(orderDate)}</p>
            ${req.ratingID ? `<p style="margin:8px 0;"><strong>Your rating:</strong> ${escapeHtml(String(req.stars))}★</p>` : ""}
            <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:8px;">
                <button class="view-order-listing-btn msg-btn">View listing</button>
                ${canRate ? `<button class="rate-order-btn msg-btn">Rate meal</button>` : ""}
            </div>
        `;

        const viewBtn = div.querySelector(".view-order-listing-btn");
        if (viewBtn) {
            viewBtn.addEventListener("click", (event) => {
                event.stopPropagation();
                openListingPage(req.listingID);
            });
        }

        const rateBtn = div.querySelector(".rate-order-btn");
        if (rateBtn) {
            rateBtn.addEventListener("click", () => showRatingModal(req.requestID));
        }

        div.addEventListener("click", event => {
            if (event.target.closest("button")) return;
            openListingPage(req.listingID);
        });

        container.appendChild(div);
    });
}

// ημερομηνια προφιλ
function formatProfileDate(value, mode = "datetime") {
    if (!value) return "Unknown date";

    const date = new Date(value);

    if (Number.isNaN(date.getTime())) {
        return String(value).replace("T", " ").slice(0, mode === "date" ? 10 : 16);
    }

    return mode === "date" ? date.toLocaleDateString() : date.toLocaleString();
}

// διαγραφη δικου μου γευματος
async function deleteMeal(id) {
    if (!confirm("Delete this listing?")) return;
    try {
        const cookId = window.UniBiteAPI?.getCurrentUserId ? window.UniBiteAPI.getCurrentUserId() : null;
        await window.UniBiteAPI.ListingsAPI.remove(id, cookId);
        showToast("Meal deleted.", "success");
    } catch (error) {
        showToast(error.message || "Could not delete meal.", "error");
    }
}

// παλιο κουμπι status
function toggleReceived(id) {
    showToast("Status changes are handled by backend requests.", "info");
}

// ανοιγμα αγγελιας
function openListingPage(listingId) {
    window.location.href = `listing.html?id=${encodeURIComponent(listingId)}`;
}

window.initProfile = initProfile;
