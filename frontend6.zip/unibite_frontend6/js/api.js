(function () {
    const DEFAULT_BASE = "http://localhost:3000";

    function getBaseUrl() {
        return localStorage.getItem("UNIBITE_API_BASE") || DEFAULT_BASE;
    }

    async function request(path, method = "GET", data = null) {
        const options = {
            method: method,
            headers: {
                "Content-Type": "application/json"
            }
        };

        if (data !== null && data !== undefined) {
            options.body = JSON.stringify(data);
        }

        const response = await fetch(getBaseUrl() + path, options);
        let result = null;

        try {
            result = await response.json();
        } catch (error) {
            result = null;
        }

        if (!response.ok) {
            throw new Error(result?.message || "Request failed");
        }

        return result;
    }

    function getCurrentUsername() {
        return localStorage.getItem("CURRENT_USER") || "";
    }

    function getCurrentUserId() {
        const saved = localStorage.getItem("CURRENT_USER_ID");
        if (saved) return Number(saved);

        const username = getCurrentUsername().replace("@", "").toLowerCase();

        const demoMap = {
            cooknwave: 1,
            chefanna: 2,
            foodie: 3,
            admin: 4
        };

        return demoMap[username] || 1;
    }

    function setCurrentUserId(id) {
        if (id !== null && id !== undefined) {
            localStorage.setItem("CURRENT_USER_ID", String(id));
        }
    }

    const ListingsAPI = {
        getAll: function () {
            return request("/listings");
        },
        getById: function (id) {
            return request("/listings/" + id);
        },
        create: function (data) {
            return request("/listings", "POST", data);
        },
        update: function (id, data) {
            return request("/listings/" + id, "PATCH", data);
        },
        remove: function (id, cookId) {
            return request("/listings/" + id, "DELETE", { cook_id: cookId });
        }
    };

    const RequestsAPI = {
        create: function (data) {
            return request("/requests", "POST", data);
        },
        getForCook: function (cookId) {
            return request("/requests/cook/" + cookId);
        },
        approve: function (id) {
            return request("/requests/" + id + "/approve", "PATCH");
        },
        reject: function (id) {
            return request("/requests/" + id + "/reject", "PATCH");
        },
        pickedUp: function (id) {
            return request("/requests/" + id + "/picked-up", "PATCH");
        },
        noShow: function (id) {
            return request("/requests/" + id + "/no-show", "PATCH");
        }
    };

    const RatingsAPI = {
        create: function (data) {
            return request("/ratings", "POST", data);
        }
    };

    const UsersAPI = {
        register: function (data) {
            return request("/users/register", "POST", data);
        },
        points: function (id) {
            return request("/users/" + id + "/points");
        }
    };

    const AdminAPI = {
        monthlyPortions: function () {
            return request("/admin/stats/monthly-portions");
        },
        topDonor: function () {
            return request("/admin/leaderboard/top-donor");
        },
        topRatedMeals: function () {
            return request("/admin/leaderboard/top-rated-meals");
        }
    };

    function mapListingToMeal(listing) {
        const id = listing.listingID ?? listing.listing_id ?? listing.id;
        const available = Number(listing.portions_available ?? listing.quantity ?? listing.portions_total ?? 0);
        const total = Number(listing.portions_total ?? available ?? 1);
        const createdAt = listing.created_at ? new Date(listing.created_at).getTime() : Date.now();
        const pickupPoint = listing.pickUP_point || listing.pickup_point || listing.pickupLocation || "";
        const pickupTime = listing.pickUP_time || listing.pickup_time || listing.pickupTime || "";

        return {
            id: id,
            backendId: id,
            cookId: listing.cook_id ?? listing.cookId,
            title: listing.title || "Untitled meal",
            desc: listing.description || listing.desc || "",
            category: listing.category || "Lunch",
            quantity: available,
            totalQuantity: total,
            pickupLocation: pickupPoint,
            pickupTime: formatPickupTime(pickupTime),
            pickupRawTime: pickupTime,
            allergens: Array.isArray(listing.allergens) ? listing.allergens : [],
            image: listing.image || listing.photo || "",
            user: listing.cook_name || listing.user || (listing.cook_id ? "Cook #" + listing.cook_id : "Unknown"),
            status: listing.status || "active",
            ts: listing.ts || createdAt,
            expiresAt: listing.expires_at || listing.expiresAt || null
        };
    }

    function mapMealToListing(meal, cookId) {
        const pickupTime = normalizePickupTime(meal.pickupTime);

        return {
            cook_id: Number(cookId),
            title: meal.title,
            description: meal.desc,
            pickup_point: meal.pickupLocation,
            pickup_time: pickupTime,
            pickUP_point: meal.pickupLocation,
            pickUP_time: pickupTime,
            portions_total: Number(meal.quantity || 1)
        };
    }

    function normalizePickupTime(value) {
        const text = String(value || "").trim();
        if (!text) return "";
        if (/^\d{4}-\d{2}-\d{2}/.test(text)) return text.replace("T", " ");
        if (/^\d{1,2}:\d{2}$/.test(text)) {
            const today = new Date().toISOString().slice(0, 10);
            return today + " " + text + ":00";
        }
        return text;
    }

    function formatPickupTime(value) {
        if (!value) return "";
        const text = String(value);
        if (text.includes("T")) return text.replace("T", " ").slice(0, 16);
        return text.slice(0, 16);
    }

    window.UniBiteAPI = {
        request: request,
        getBaseUrl: getBaseUrl,
        getCurrentUserId: getCurrentUserId,
        setCurrentUserId: setCurrentUserId,
        ListingsAPI: ListingsAPI,
        RequestsAPI: RequestsAPI,
        RatingsAPI: RatingsAPI,
        UsersAPI: UsersAPI,
        AdminAPI: AdminAPI,
        mapListingToMeal: mapListingToMeal,
        mapMealToListing: mapMealToListing,
        normalizePickupTime: normalizePickupTime
    };
})();
