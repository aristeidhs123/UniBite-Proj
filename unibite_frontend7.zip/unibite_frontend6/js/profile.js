// ../js/profile.js
// Handles the profile page display and editing experience.
// Includes profile summary, photo upload preview, personal info editing,
// and list of current user's meal listings.

let selectedProfilePhoto = null;

function initProfile() {
    console.log("initProfile called");
    renderProfileSummary();
    loadProfileEditForm();
    loadUserListings();
    loadUserOrders();
    initProfileTabs();
    window.addEventListener("rating-submitted", loadUserOrders);

    const editBtn = document.getElementById("edit-profile-btn");
    const cancelBtn = document.getElementById("cancel-profile-btn");
    const photoInput = document.getElementById("profile-photo-input");
    const form = document.getElementById("profile-form");

    if (editBtn) {
        editBtn.addEventListener("click", () => {
            toggleProfileEditPanel(true);
        });
    }

    if (cancelBtn) {
        cancelBtn.addEventListener("click", () => {
            toggleProfileEditPanel(false);
        });
    }

    if (photoInput) {
        photoInput.addEventListener("change", handleProfilePhotoChange);
    }

    if (form) {
        form.addEventListener("submit", (e) => {
            e.preventDefault();
            saveProfile();
        });
    }
}

function renderProfileSummary() {
    const usernameEl = document.getElementById("profile-username");
    const pointsEl = document.getElementById("profile-points");
    const emailDisplay = document.getElementById("profile-email-display");
    const locationDisplay = document.getElementById("profile-location-display");
    const displayNameEl = document.getElementById("profile-display-name");
    const avatarImg = document.getElementById("profile-avatar-image");
    const avatarInitials = document.getElementById("profile-avatar-initials");

    const profile = getCurrentUserProfile();
    const username = profile?.username || window.CURRENT_USER || "";
    const displayName = profile?.displayName || username;
    const email = profile?.email || "-";
    const location = profile?.location || "-";
    const photo = profile?.photo || "";

    if (displayNameEl) {
        displayNameEl.textContent = displayName;
    }
    if (usernameEl) {
        usernameEl.textContent = username;
    }
    if (pointsEl) {
        pointsEl.textContent = profile?.points ?? 0;
    }
    if (emailDisplay) {
        emailDisplay.textContent = `Email: ${email}`;
    }
    if (locationDisplay) {
        locationDisplay.textContent = `Location: ${location}`;
    }

    if (photo && avatarImg) {
        avatarImg.src = photo;
        avatarImg.style.display = "block";
        avatarInitials.style.display = "none";
    } else {
        if (avatarImg) avatarImg.style.display = "none";
        if (avatarInitials) {
            avatarInitials.style.display = "block";
            avatarInitials.textContent = getInitials(displayName || username);
        }
    }
}

function loadProfileEditForm() {
    const displayNameInput = document.getElementById("profile-display-name-input");
    const emailInput = document.getElementById("profile-email-input");
    const locationInput = document.getElementById("profile-location-input");
    const profilePhotoPreviewWrap = document.getElementById("profile-photo-preview-wrap");
    const profilePhotoPreview = document.getElementById("profile-photo-preview");

    const profile = getCurrentUserProfile();
    const displayName = profile?.displayName || profile?.username || window.CURRENT_USER || "";

    if (displayNameInput) {
        displayNameInput.value = displayName;
    }
    if (emailInput) {
        emailInput.value = profile?.email || "";
    }
    if (locationInput) {
        locationInput.value = profile?.location || "";
    }

    selectedProfilePhoto = profile?.photo || null;
    if (selectedProfilePhoto && profilePhotoPreview && profilePhotoPreviewWrap) {
        profilePhotoPreview.src = selectedProfilePhoto;
        profilePhotoPreviewWrap.style.display = "block";
    } else if (profilePhotoPreviewWrap) {
        profilePhotoPreviewWrap.style.display = "none";
    }

    toggleProfileEditPanel(false);
}

function toggleProfileEditPanel(show) {
    const panel = document.getElementById("profile-edit-panel");
    if (!panel) return;
    if (typeof show === "boolean") {
        panel.classList.toggle("hidden", !show);
    } else {
        panel.classList.toggle("hidden");
    }
}

function handleProfilePhotoChange(event) {
    const file = event.target.files[0];
    const previewWrap = document.getElementById("profile-photo-preview-wrap");
    const preview = document.getElementById("profile-photo-preview");

    if (!file || !preview || !previewWrap) {
        return;
    }

    const reader = new FileReader();
    reader.onload = () => {
        selectedProfilePhoto = reader.result;
        preview.src = reader.result;
        previewWrap.style.display = "block";
    };
    reader.readAsDataURL(file);
}

function getInitials(text) {
    const words = String(text).trim().split(/\s+/);
    if (words.length === 0) return "?";
    if (words.length === 1) return words[0].charAt(0).toUpperCase();
    return `${words[0].charAt(0)}${words[1].charAt(0)}`.toUpperCase();
}

function saveProfile() {
    const displayNameInput = document.getElementById("profile-display-name-input");
    const emailInput = document.getElementById("profile-email-input");
    const locationInput = document.getElementById("profile-location-input");

    if (!displayNameInput || !emailInput || !locationInput) {
        return;
    }

    const profile = getCurrentUserProfile();
    if (!profile) return;

    const updated = {
        ...profile,
        displayName: displayNameInput.value.trim() || profile.username,
        email: emailInput.value.trim(),
        location: locationInput.value.trim(),
        photo: selectedProfilePhoto || profile.photo || ""
    };

    updateUserProfile(updated);
    showToast("Profile updated successfully.", "success");
    renderProfileSummary();
    loadProfileEditForm();
}

// Load all meal listings created by the current user into the profile page.
async function loadUserListings() {
    const container = document.getElementById("profile-listings");
    if (!container) return;
    container.innerHTML = "<p style='text-align:center;padding:20px;color:#666;'>Loading your meals...</p>";

    let userMeals = [];

    try {
        const cookId = window.UniBiteAPI?.getCurrentUserId ? window.UniBiteAPI.getCurrentUserId() : null;
        const meals = await mealService.getAllRemote();
        userMeals = meals.filter(meal => Number(meal.cookId) === Number(cookId) && String(meal.status || "") !== "deleted");
    } catch (error) {
        container.innerHTML = `<p style='text-align:center;padding:20px;color:#666;'>Could not load your meals from backend.</p>`;
        return;
    }

    if (userMeals.length === 0) {
        container.innerHTML = "<p style='text-align:center;padding:20px;color:#666;'>No cooked meals yet. Upload a meal!</p>";
        return;
    }

    userMeals.sort((a, b) => (Number(b.ts || b.id || 0) - Number(a.ts || a.id || 0)));

    userMeals.forEach(meal => {
        const div = document.createElement("div");
        div.className = "listing";
        div.dataset.id = meal.id;

        div.innerHTML = `
            <div class="listing-row" style="display:flex;gap:12px;align-items:center;">
                <div class="listing-thumb" style="width:140px;height:140px;border-radius:12px;overflow:hidden;background:#eee;flex-shrink:0;">
                    ${meal.image ? `<img src="${meal.image}" style="width:100%;height:100%;object-fit:cover;">` : `<div style="width:100%;height:100%;display:flex;align-items:center;justify-content:center;color:#999">No Image</div>`}
                </div>
                <div style="flex:1">
                    <h3 style="margin:0 0 6px 0">${escapeHtml(meal.title)}</h3>
                    <p style="margin:0 0 6px 0;color:#555">${escapeHtml(meal.desc)}</p>
                    <small class="listing-category">Category: ${escapeHtml(meal.category || "n/a")}</small>
                    <div style="margin-top:6px;font-size:13px;color:#666;">
                        Portions: ${Number(meal.quantity == null ? 1 : meal.quantity)} &middot; Pickup: ${escapeHtml(meal.pickupLocation || "n/a")} at ${escapeHtml(meal.pickupTime || "n/a")}
                    </div>
                    <div style="margin-top:8px;display:flex;gap:8px;flex-wrap:wrap;align-items:center;">
                        <button class="edit-btn msg-btn">Edit</button>
                        <button class="delete-btn msg-btn">Delete</button>
                        <button class="toggle-btn msg-btn">${meal.status === "received" ? "Mark Available" : "Mark Received"}</button>
                        <button class="view-btn msg-btn">View</button>
                    </div>
                    <div style="margin-top:6px;font-size:13px;color:#666;">
                        <strong>Status:</strong> ${escapeHtml(meal.status || "available")}
                    </div>
                </div>
            </div>
        `;

        const editBtn = div.querySelector(".edit-btn");
        const deleteBtn = div.querySelector(".delete-btn");
        const toggleBtn = div.querySelector(".toggle-btn");
        const viewBtn = div.querySelector(".view-btn");

        if (editBtn) editBtn.addEventListener("click", (e) => { e.stopPropagation(); sessionStorage.setItem("editMealId", meal.id); window.location.href = "upload.html"; });
        if (deleteBtn) deleteBtn.addEventListener("click", async (e) => { e.stopPropagation(); await deleteMeal(meal.id); loadUserListings(); });
        if (toggleBtn) toggleBtn.style.display = "none";
        if (viewBtn) viewBtn.addEventListener("click", (e) => { e.stopPropagation(); openListingPage(meal.id); });

        div.addEventListener("click", (e) => { if (e.target.closest("button")) return; openListingPage(meal.id); });

        container.appendChild(div);
    });
}

function initProfileTabs() {
    const tabs = document.querySelectorAll(".profile-tab-btn");
    tabs.forEach(btn => {
        btn.addEventListener("click", () => {
            setProfileTab(btn.dataset.tab);
        });
    });
    setProfileTab("meals");
}

function setProfileTab(tab) {
    document.querySelectorAll(".profile-tab-btn").forEach(btn => {
        btn.classList.toggle("active", btn.dataset.tab === tab);
    });
    const mealsPanel = document.getElementById("profile-meals-panel");
    const ordersPanel = document.getElementById("profile-orders-panel");
    if (mealsPanel) {
        mealsPanel.classList.toggle("hidden", tab !== "meals");
    }
    if (ordersPanel) {
        ordersPanel.classList.toggle("hidden", tab !== "orders");
    }
}

async function loadUserOrders() {
    const container = document.getElementById("profile-orders");
    if (!container) return;
    container.innerHTML = "<p style='text-align:center;padding:20px;color:#666;'>Loading your orders...</p>";

    let userOrders = [];

    try {
        const consumerId = window.UniBiteAPI?.getCurrentUserId ? window.UniBiteAPI.getCurrentUserId() : null;
        userOrders = await window.UniBiteAPI.RequestsAPI.getForConsumer(consumerId);
    } catch (error) {
        container.innerHTML = "<p style='text-align:center;padding:20px;color:#666;'>Could not load your orders from backend.</p>";
        return;
    }

    if (userOrders.length === 0) {
        container.innerHTML = "<p style='text-align:center;padding:20px;color:#666;'>No orders yet.</p>";
        return;
    }

    userOrders.forEach(req => {
        const div = document.createElement("div");
        div.className = "listing profile-order-card";
        const orderDate = req.created_at ? new Date(req.created_at).toLocaleDateString() : "Unknown date";
        const canRate = req.status === "picked_up" && !req.ratingID;
        div.innerHTML = `
            <h4>${escapeHtml(req.title || req.mealTitle || "Meal")}</h4>
            <p style="margin:4px 0;"><strong>Cook:</strong> ${escapeHtml(req.cook_name || req.to || "-")}</p>
            <p style="margin:4px 0;"><strong>Status:</strong> ${escapeHtml(req.status || "pending")}</p>
            <p style="margin:4px 0;"><strong>Pickup:</strong> ${escapeHtml(req.pickUP_point || req.pickup_point || "-")} at ${escapeHtml(req.pickUP_time || req.pickup_time || "-")}</p>
            <p class="order-status">Ordered on ${escapeHtml(orderDate)}</p>
            ${req.ratingID ? `<p style="margin:8px 0;"><strong>Your rating:</strong> ${escapeHtml(String(req.stars))}★</p>` : ""}
            ${canRate ? `<button class="rate-order-btn msg-btn">Rate meal</button>` : ""}
        `;

        const rateBtn = div.querySelector(".rate-order-btn");
        if (rateBtn) {
            rateBtn.addEventListener("click", () => showRatingModal(req.requestID));
        }

        container.appendChild(div);
    });
}

// Mark a meal listing as deleted without removing it completely from storage.
async function deleteMeal(id) {
    if (!confirm("Delete this listing?")) return;
    try {
        const cookId = window.UniBiteAPI?.getCurrentUserId ? window.UniBiteAPI.getCurrentUserId() : null;
        await window.UniBiteAPI.ListingsAPI.remove(id, cookId);
        showToast("Meal deleted.", "success");
    } catch (error) {
        showToast(error.message || "Could not delete meal.", "error");
    }
}

// Toggle the meal status between received and available on the profile page.
function toggleReceived(id) {
    showToast("Status changes are handled by backend requests.", "info");
}

function openListingPage(listingId) {
    window.location.href = `listing.html?id=${encodeURIComponent(listingId)}`;
}

window.initProfile = initProfile;
