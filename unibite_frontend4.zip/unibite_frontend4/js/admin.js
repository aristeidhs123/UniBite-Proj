async function initAdmin() {
    const isAdmin = localStorage.getItem("IS_ADMIN") === "true";
    const currentUser = localStorage.getItem("CURRENT_USER");

    if (!isAdmin && normalizeUser(currentUser) !== "admin") {
        showToast("Access denied. Admin only.", "error");
        window.location.href = "index.html";
        return;
    }

    await loadTotalPortions();
    await loadTopDonor();
    await loadTopMeals();
}

async function loadTotalPortions() {
    const totalEl = document.getElementById("total-portions");
    if (!totalEl) return;

    try {
        const result = await window.UniBiteAPI.AdminAPI.monthlyPortions();

        totalEl.textContent =
            result?.total_portions_shared_last_month ??
            result?.totalPortions ??
            result?.total_portions ??
            result?.data?.total_portions_shared_last_month ??
            result?.data?.totalPortions ??
            0;
    } catch (error) {
        totalEl.textContent = getDeliveredRequests().length;
    }
}

async function loadTopDonor() {
    const tbody = document.getElementById("top-donor-body");
    if (!tbody) return;

    try {
        const result = await window.UniBiteAPI.AdminAPI.topDonor();
        const donor = Array.isArray(result) ? result[0] : (result?.data || result);

        if (!donor || donor.message) {
            renderEmpty(tbody, 3, "No donor data yet.");
            return;
        }

        tbody.innerHTML = `
            <tr>
                <td>${escapeHtml(donor.name_lastname || donor.username || donor.name || "Student")}</td>
                <td><strong>${donor.portions_shared || donor.portionsGiven || donor.total_portions || 0}</strong></td>
                <td>${donor.points ?? "-"}</td>
            </tr>
        `;
    } catch (error) {
        renderLocalTopDonor(tbody);
    }
}

async function loadTopMeals() {
    const tbody = document.getElementById("top-meals-body");
    if (!tbody) return;

    try {
        const result = await window.UniBiteAPI.AdminAPI.topRatedMeals();
        const meals = Array.isArray(result) ? result : (result?.data || result?.meals || []);

        if (!meals.length) {
            renderEmpty(tbody, 5, "No rated meals yet.");
            return;
        }

        tbody.innerHTML = meals.map(function (meal, index) {
            return `
                <tr>
                    <td>${index + 1}</td>
                    <td>${escapeHtml(meal.title || meal.meal_title || "Meal")}</td>
                    <td>${escapeHtml(meal.cook_name || meal.cook || "Cook")}</td>
                    <td><strong>${Number(meal.average_rating || meal.avgRating || 0).toFixed(1)}★</strong></td>
                    <td>${meal.total_ratings || meal.ratingsCount || 0}</td>
                </tr>
            `;
        }).join("");
    } catch (error) {
        renderLocalTopMeals(tbody);
    }
}

function renderLocalTopDonor(tbody) {
    const users = getUsers();
    const requests = getDeliveredRequests();

    const donors = users.map(function (user) {
        const portions = requests.filter(function (request) {
            return normalizeUser(request.to) === normalizeUser(user.username);
        }).length;

        return {
            username: user.username,
            portions: portions,
            points: user.points || 0
        };
    }).filter(function (user) {
        return user.portions > 0;
    }).sort(function (a, b) {
        return b.portions - a.portions;
    });

    if (!donors.length) {
        renderEmpty(tbody, 3, "No donor data yet.");
        return;
    }

    const donor = donors[0];

    tbody.innerHTML = `
        <tr>
            <td>${escapeHtml(donor.username)}</td>
            <td><strong>${donor.portions}</strong></td>
            <td>${donor.points}</td>
        </tr>
    `;
}

function renderLocalTopMeals(tbody) {
    const meals = mealService.getAll();
    const ratings = JSON.parse(localStorage.getItem("ratings") || "[]");

    const topMeals = meals.map(function (meal) {
        const mealRatings = ratings.filter(function (rating) {
            return String(rating.mealId) === String(meal.id);
        });

        return {
            title: meal.title,
            cook: meal.user,
            avgRating: calculateAverageRating(mealRatings),
            ratingsCount: mealRatings.length
        };
    }).filter(function (meal) {
        return meal.ratingsCount > 0;
    }).sort(function (a, b) {
        return Number(b.avgRating) - Number(a.avgRating);
    }).slice(0, 5);

    if (!topMeals.length) {
        renderEmpty(tbody, 5, "No rated meals yet.");
        return;
    }

    tbody.innerHTML = topMeals.map(function (meal, index) {
        return `
            <tr>
                <td>${index + 1}</td>
                <td>${escapeHtml(meal.title)}</td>
                <td>${escapeHtml(meal.cook)}</td>
                <td><strong>${meal.avgRating}★</strong></td>
                <td>${meal.ratingsCount}</td>
            </tr>
        `;
    }).join("");
}

function getDeliveredRequests() {
    const requests = JSON.parse(localStorage.getItem("requests") || "[]");

    return requests.filter(function (request) {
        return ["delivered", "picked_up"].includes(request.status);
    });
}

function calculateAverageRating(ratings) {
    if (!ratings.length) return "0.0";

    const sum = ratings.reduce(function (total, rating) {
        return total + Number(rating.stars || 0);
    }, 0);

    return (sum / ratings.length).toFixed(1);
}

function renderEmpty(tbody, colspan, message) {
    tbody.innerHTML = `
        <tr>
            <td colspan="${colspan}" class="empty-cell">${escapeHtml(message)}</td>
        </tr>
    `;
}

window.initAdmin = initAdmin;
